class Professor extends Pessoa{
    constructor(nome, idade, disciplina){
        super(nome, idade);
        this.disciplina=disciplina;
    }

    ensinar(){
        return`
        Nome:${this.nome}
        Idade:${this.idade}
        Disciplina:${this.disciplina}
        `;
    }
}

const pessoa2 = Pessoa(
    "Tiago",
    32
)

const professor1 = Professor(
    "Tiago",
    32,
    "Matemática"
)